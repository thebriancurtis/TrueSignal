# Rule Sets: Method

This folder contains compiled rule sets for the **method** theme.

Each `.json` file defines a named set of rule IDs conforming to `rule_set.json`.
