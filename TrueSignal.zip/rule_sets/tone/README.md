# Rule Sets: Tone

This folder contains compiled rule sets for the **tone** theme.

Each `.json` file defines a named set of rule IDs conforming to `rule_set.json`.
