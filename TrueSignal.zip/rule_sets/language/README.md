# Rule Sets: Language

This folder contains compiled rule sets for the **language** theme.

Each `.json` file defines a named set of rule IDs conforming to `rule_set.json`.
