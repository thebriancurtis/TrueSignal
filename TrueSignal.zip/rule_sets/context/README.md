# Rule Sets: Context

This folder contains compiled rule sets for the **context** theme.

Each `.json` file defines a named set of rule IDs conforming to `rule_set.json`.
