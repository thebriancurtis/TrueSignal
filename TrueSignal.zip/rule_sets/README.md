# Compiled Rule Sets

This folder contains compiled rule sets intended for public use. Each subfolder represents a category of behavior (see `rule_set_categorization.json`).

Each compiled rule set includes rules from `core` and any explicitly included sets.
