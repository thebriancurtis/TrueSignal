# Prompts

This folder contains an AI assistant prompts that:
- Validate rules or rule sets
- Suggest categories
- Optimize or deduplicate rule text

Each file is a `.json` an AI assistant-native instruction block used in tooling and workflows.
