# Standards Documentation (Internal)

Documentation of internal-only JSON schemas and metadata used to support validation, deduplication, or contributor tooling.
