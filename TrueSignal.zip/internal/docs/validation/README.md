# Validation Framework Docs

This folder documents validation systems used in TrueSignal to lint, deduplicate, and optimize rule sets and prompts.

Includes prompt composition and test-case generation tooling.
