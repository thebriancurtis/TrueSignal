# Architecture Documentation

Design documentation and architectural reasoning for the structure and systems behind TrueSignal.

Useful for anyone maintaining or extending the project internals.
