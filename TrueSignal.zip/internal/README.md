# Internal

This folder contains all project-internal logic, data, and specifications not directly exposed to end users.

This includes architecture documentation, core logic, internal rule sets, and test harnesses.
