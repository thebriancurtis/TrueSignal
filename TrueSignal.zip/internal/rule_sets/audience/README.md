# Internal Rule Sets: Audience

This folder contains raw, authorable rule sets for the **audience** theme.

Each file will be validated and compiled into `/rule_sets/audience/`.
