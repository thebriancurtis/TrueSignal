# Internal Rule Sets: Persona

This folder contains raw, authorable rule sets for the **persona** theme.

Each file will be validated and compiled into `/rule_sets/persona/`.
