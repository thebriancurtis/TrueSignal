# Internal Rule Sets

Source rule sets used before compilation. These include raw rules and references to other sets.

Compiled rule sets are exported to `/rule_sets` for public use.
