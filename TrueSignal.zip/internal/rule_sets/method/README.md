# Internal Rule Sets: Method

This folder contains raw, authorable rule sets for the **method** theme.

Each file will be validated and compiled into `/rule_sets/method/`.
