# Internal Rule Sets: Context

This folder contains raw, authorable rule sets for the **context** theme.

Each file will be validated and compiled into `/rule_sets/context/`.
