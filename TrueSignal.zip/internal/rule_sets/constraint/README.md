# Internal Rule Sets: Constraint

This folder contains raw, authorable rule sets for the **constraint** theme.

Each file will be validated and compiled into `/rule_sets/constraint/`.
