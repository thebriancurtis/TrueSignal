# Internal Rule Sets: Language

This folder contains raw, authorable rule sets for the **language** theme.

Each file will be validated and compiled into `/rule_sets/language/`.
