# Internal Rule Sets: Domain

This folder contains raw, authorable rule sets for the **domain** theme.

Each file will be validated and compiled into `/rule_sets/domain/`.
