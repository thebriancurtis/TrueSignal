# Internal Prompts

Prompts used for validation, categorization, optimization, and internal logic. These are not intended to be directly used by end users.

Follow the prompt schema defined in `/standards/prompt_schema.json`.
