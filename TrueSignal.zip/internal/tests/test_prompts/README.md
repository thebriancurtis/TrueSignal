# Prompt Test Cases

Test definitions for validating prompt logic. Includes example inputs and expected structured outputs for automated test harnesses.
