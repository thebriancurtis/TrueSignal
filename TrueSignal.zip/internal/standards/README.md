# Internal Standards

JSON schemas and other constraint definitions used by the internal tooling, including contributor prompts and precompiled validation assets.
