# Core Logic

This folder contains logic and assets that apply globally across the TrueSignal system.

Core rules and framework components live here.
