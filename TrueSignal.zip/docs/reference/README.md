# Reference

This folder contains markdown documentation for each public-facing JSON schema defined in the `/standards` directory.

Each file provides:
- A description of the schema’s purpose
- Key fields and usage patterns
- Related documentation and implementation notes
