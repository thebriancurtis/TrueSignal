# rule_set_resolution.json
Defines where rule sets and rules may be located. Used during rule set compilation to validate sources.