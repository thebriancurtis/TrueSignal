# Rule Set Categorization

Each rule set belongs to a category defined in this JSON.

## Categories Include
- `tone`
- `persona`
- `domain`
- `constraint`
- `context`
- `language`
- `tool`
- `audience`
- `method`

Used by: `suggest_rule_set_category.json`