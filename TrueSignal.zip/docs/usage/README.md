# Usage Guides

This folder contains documentation that explains how to use TrueSignal as an end user. These documents cover how to incorporate rule sets, structure prompts, and apply validation effectively.

Intended for: Anyone integrating TrueSignal into AI assistant workflows.
