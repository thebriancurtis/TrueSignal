# Writing Guidance

This folder contains writing guides for contributors working on rules, rule sets, and prompts. It includes how-to documents, quality checklists, and usage patterns.

Intended for: Contributors and advanced users.
