# NOTICE

This project is developed and maintained by Brian Curtis.

GitHub: https://github.com/thebriancurtis  
LinkedIn: https://www.linkedin.com/in/thebriancurtis

Licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0).  
See LICENSE for full terms.
